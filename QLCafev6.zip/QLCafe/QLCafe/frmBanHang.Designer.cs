﻿namespace QLCafe
{
    partial class frmBanHang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmBanHang));
            this.panelControl1 = new DevExpress.XtraEditors.PanelControl();
            this.groupControl4 = new DevExpress.XtraEditors.GroupControl();
            this.txtTyLyPhucVu = new DevExpress.XtraEditors.LabelControl();
            this.btnCoNguoi = new DevExpress.XtraEditors.SimpleButton();
            this.btnDatTruoc = new DevExpress.XtraEditors.SimpleButton();
            this.btnTrong = new DevExpress.XtraEditors.SimpleButton();
            this.panelControl4 = new DevExpress.XtraEditors.PanelControl();
            this.panelControl3 = new DevExpress.XtraEditors.PanelControl();
            this.panelControl2 = new DevExpress.XtraEditors.PanelControl();
            this.gridControlCTHD = new DevExpress.XtraGrid.GridControl();
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn3 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn4 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn5 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn6 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn7 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn8 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn9 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.barManager1 = new DevExpress.XtraBars.BarManager(this.components);
            this.barDockControlTop = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlBottom = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlLeft = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlRight = new DevExpress.XtraBars.BarDockControl();
            this.barButtonItem1 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonXoaBan = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonChuyenBan = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonGopBan = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem5 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonDatBan = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonTachBan = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonChonMon = new DevExpress.XtraBars.BarButtonItem();
            this.groupControl1 = new DevExpress.XtraEditors.GroupControl();
            this.tblTable1 = new System.Windows.Forms.FlowLayoutPanel();
            this.menuBan = new DevExpress.XtraBars.PopupMenu(this.components);
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl3 = new DevExpress.XtraEditors.LabelControl();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).BeginInit();
            this.panelControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl4)).BeginInit();
            this.groupControl4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl4)).BeginInit();
            this.panelControl4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl2)).BeginInit();
            this.panelControl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridControlCTHD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.barManager1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).BeginInit();
            this.groupControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.menuBan)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelControl1
            // 
            this.panelControl1.Controls.Add(this.groupControl4);
            this.panelControl1.Controls.Add(this.panelControl4);
            this.panelControl1.Controls.Add(this.panelControl3);
            this.panelControl1.Controls.Add(this.panelControl2);
            this.panelControl1.Controls.Add(this.groupControl1);
            this.panelControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelControl1.Location = new System.Drawing.Point(0, 0);
            this.panelControl1.Name = "panelControl1";
            this.panelControl1.Size = new System.Drawing.Size(1307, 679);
            this.panelControl1.TabIndex = 0;
            // 
            // groupControl4
            // 
            this.groupControl4.Controls.Add(this.txtTyLyPhucVu);
            this.groupControl4.Controls.Add(this.btnCoNguoi);
            this.groupControl4.Controls.Add(this.btnDatTruoc);
            this.groupControl4.Controls.Add(this.btnTrong);
            this.groupControl4.Location = new System.Drawing.Point(5, 4);
            this.groupControl4.Name = "groupControl4";
            this.groupControl4.Size = new System.Drawing.Size(560, 105);
            this.groupControl4.TabIndex = 8;
            this.groupControl4.Text = "Trạng Thái";
            // 
            // txtTyLyPhucVu
            // 
            this.txtTyLyPhucVu.Location = new System.Drawing.Point(10, 77);
            this.txtTyLyPhucVu.Name = "txtTyLyPhucVu";
            this.txtTyLyPhucVu.Size = new System.Drawing.Size(63, 13);
            this.txtTyLyPhucVu.TabIndex = 1;
            this.txtTyLyPhucVu.Text = "labelControl5";
            // 
            // btnCoNguoi
            // 
            this.btnCoNguoi.Location = new System.Drawing.Point(204, 26);
            this.btnCoNguoi.Name = "btnCoNguoi";
            this.btnCoNguoi.Size = new System.Drawing.Size(98, 36);
            this.btnCoNguoi.TabIndex = 0;
            // 
            // btnDatTruoc
            // 
            this.btnDatTruoc.Location = new System.Drawing.Point(100, 26);
            this.btnDatTruoc.Name = "btnDatTruoc";
            this.btnDatTruoc.Size = new System.Drawing.Size(98, 36);
            this.btnDatTruoc.TabIndex = 0;
            // 
            // btnTrong
            // 
            this.btnTrong.Location = new System.Drawing.Point(7, 26);
            this.btnTrong.Name = "btnTrong";
            this.btnTrong.Size = new System.Drawing.Size(87, 36);
            this.btnTrong.TabIndex = 0;
            // 
            // panelControl4
            // 
            this.panelControl4.Controls.Add(this.tableLayoutPanel1);
            this.panelControl4.Location = new System.Drawing.Point(573, 483);
            this.panelControl4.Name = "panelControl4";
            this.panelControl4.Size = new System.Drawing.Size(720, 184);
            this.panelControl4.TabIndex = 7;
            // 
            // panelControl3
            // 
            this.panelControl3.Location = new System.Drawing.Point(571, 4);
            this.panelControl3.Name = "panelControl3";
            this.panelControl3.Size = new System.Drawing.Size(722, 105);
            this.panelControl3.TabIndex = 6;
            // 
            // panelControl2
            // 
            this.panelControl2.Controls.Add(this.gridControlCTHD);
            this.panelControl2.Location = new System.Drawing.Point(571, 111);
            this.panelControl2.Name = "panelControl2";
            this.panelControl2.Size = new System.Drawing.Size(724, 366);
            this.panelControl2.TabIndex = 5;
            // 
            // gridControlCTHD
            // 
            this.gridControlCTHD.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridControlCTHD.Location = new System.Drawing.Point(2, 2);
            this.gridControlCTHD.MainView = this.gridView1;
            this.gridControlCTHD.MenuManager = this.barManager1;
            this.gridControlCTHD.Name = "gridControlCTHD";
            this.gridControlCTHD.Size = new System.Drawing.Size(720, 362);
            this.gridControlCTHD.TabIndex = 0;
            this.gridControlCTHD.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView1});
            // 
            // gridView1
            // 
            this.gridView1.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn1,
            this.gridColumn2,
            this.gridColumn3,
            this.gridColumn4,
            this.gridColumn5,
            this.gridColumn6,
            this.gridColumn7,
            this.gridColumn8,
            this.gridColumn9});
            this.gridView1.GridControl = this.gridControlCTHD;
            this.gridView1.Name = "gridView1";
            this.gridView1.OptionsDetail.DetailMode = DevExpress.XtraGrid.Views.Grid.DetailMode.Default;
            this.gridView1.OptionsView.ShowGroupPanel = false;
            // 
            // gridColumn1
            // 
            this.gridColumn1.Caption = "Mã Món";
            this.gridColumn1.FieldName = "MaHangHoa";
            this.gridColumn1.Name = "gridColumn1";
            this.gridColumn1.OptionsColumn.AllowEdit = false;
            this.gridColumn1.Visible = true;
            this.gridColumn1.VisibleIndex = 0;
            this.gridColumn1.Width = 52;
            // 
            // gridColumn2
            // 
            this.gridColumn2.Caption = "Tên Món";
            this.gridColumn2.FieldName = "TenHangHoa";
            this.gridColumn2.Name = "gridColumn2";
            this.gridColumn2.OptionsColumn.AllowEdit = false;
            this.gridColumn2.Visible = true;
            this.gridColumn2.VisibleIndex = 1;
            this.gridColumn2.Width = 90;
            // 
            // gridColumn3
            // 
            this.gridColumn3.Caption = "ĐVT";
            this.gridColumn3.FieldName = "DonViTinh";
            this.gridColumn3.Name = "gridColumn3";
            this.gridColumn3.OptionsColumn.AllowEdit = false;
            this.gridColumn3.Visible = true;
            this.gridColumn3.VisibleIndex = 2;
            this.gridColumn3.Width = 35;
            // 
            // gridColumn4
            // 
            this.gridColumn4.Caption = "Số Lượng";
            this.gridColumn4.FieldName = "SoLuong";
            this.gridColumn4.Name = "gridColumn4";
            this.gridColumn4.Visible = true;
            this.gridColumn4.VisibleIndex = 3;
            this.gridColumn4.Width = 53;
            // 
            // gridColumn5
            // 
            this.gridColumn5.Caption = "Đơn Giá";
            this.gridColumn5.DisplayFormat.FormatString = "{0:#,# đ}";
            this.gridColumn5.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Custom;
            this.gridColumn5.FieldName = "DonGia";
            this.gridColumn5.Name = "gridColumn5";
            this.gridColumn5.OptionsColumn.AllowEdit = false;
            this.gridColumn5.Visible = true;
            this.gridColumn5.VisibleIndex = 4;
            this.gridColumn5.Width = 69;
            // 
            // gridColumn6
            // 
            this.gridColumn6.Caption = "Phụ Thu Theo Giờ";
            this.gridColumn6.DisplayFormat.FormatString = "{0:#,# đ}";
            this.gridColumn6.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Custom;
            this.gridColumn6.FieldName = "PhuThuGio";
            this.gridColumn6.Name = "gridColumn6";
            this.gridColumn6.OptionsColumn.AllowEdit = false;
            this.gridColumn6.Visible = true;
            this.gridColumn6.VisibleIndex = 5;
            this.gridColumn6.Width = 96;
            // 
            // gridColumn7
            // 
            this.gridColumn7.Caption = "Phụ Thu Theo Khu Vực";
            this.gridColumn7.DisplayFormat.FormatString = "{0:#,# đ}";
            this.gridColumn7.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Custom;
            this.gridColumn7.FieldName = "PhuThuKhuVuc";
            this.gridColumn7.Name = "gridColumn7";
            this.gridColumn7.OptionsColumn.AllowEdit = false;
            this.gridColumn7.Visible = true;
            this.gridColumn7.VisibleIndex = 6;
            this.gridColumn7.Width = 125;
            // 
            // gridColumn8
            // 
            this.gridColumn8.Caption = "Giá Tổng";
            this.gridColumn8.DisplayFormat.FormatString = "{0:#,# đ}";
            this.gridColumn8.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Custom;
            this.gridColumn8.FieldName = "GiaTong";
            this.gridColumn8.Name = "gridColumn8";
            this.gridColumn8.OptionsColumn.AllowEdit = false;
            this.gridColumn8.Visible = true;
            this.gridColumn8.VisibleIndex = 7;
            this.gridColumn8.Width = 82;
            // 
            // gridColumn9
            // 
            this.gridColumn9.Caption = "Thành Tiền";
            this.gridColumn9.DisplayFormat.FormatString = "{0:#,# đ}";
            this.gridColumn9.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Custom;
            this.gridColumn9.FieldName = "ThanhTien";
            this.gridColumn9.Name = "gridColumn9";
            this.gridColumn9.OptionsColumn.AllowEdit = false;
            this.gridColumn9.Visible = true;
            this.gridColumn9.VisibleIndex = 8;
            this.gridColumn9.Width = 97;
            // 
            // barManager1
            // 
            this.barManager1.DockControls.Add(this.barDockControlTop);
            this.barManager1.DockControls.Add(this.barDockControlBottom);
            this.barManager1.DockControls.Add(this.barDockControlLeft);
            this.barManager1.DockControls.Add(this.barDockControlRight);
            this.barManager1.Form = this;
            this.barManager1.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.barButtonItem1,
            this.barButtonXoaBan,
            this.barButtonChuyenBan,
            this.barButtonGopBan,
            this.barButtonItem5,
            this.barButtonDatBan,
            this.barButtonTachBan,
            this.barButtonChonMon});
            this.barManager1.MaxItemId = 8;
            // 
            // barDockControlTop
            // 
            this.barDockControlTop.CausesValidation = false;
            this.barDockControlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.barDockControlTop.Location = new System.Drawing.Point(0, 0);
            this.barDockControlTop.Size = new System.Drawing.Size(1307, 0);
            // 
            // barDockControlBottom
            // 
            this.barDockControlBottom.CausesValidation = false;
            this.barDockControlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.barDockControlBottom.Location = new System.Drawing.Point(0, 679);
            this.barDockControlBottom.Size = new System.Drawing.Size(1307, 0);
            // 
            // barDockControlLeft
            // 
            this.barDockControlLeft.CausesValidation = false;
            this.barDockControlLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.barDockControlLeft.Location = new System.Drawing.Point(0, 0);
            this.barDockControlLeft.Size = new System.Drawing.Size(0, 679);
            // 
            // barDockControlRight
            // 
            this.barDockControlRight.CausesValidation = false;
            this.barDockControlRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.barDockControlRight.Location = new System.Drawing.Point(1307, 0);
            this.barDockControlRight.Size = new System.Drawing.Size(0, 679);
            // 
            // barButtonItem1
            // 
            this.barButtonItem1.Caption = "Đặt Bàn";
            this.barButtonItem1.Id = 0;
            this.barButtonItem1.Name = "barButtonItem1";
            // 
            // barButtonXoaBan
            // 
            this.barButtonXoaBan.Caption = "Xóa Bàn";
            this.barButtonXoaBan.Id = 1;
            this.barButtonXoaBan.ImageUri.Uri = "Cancel";
            this.barButtonXoaBan.Name = "barButtonXoaBan";
            this.barButtonXoaBan.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonXoaBan_ItemClick);
            // 
            // barButtonChuyenBan
            // 
            this.barButtonChuyenBan.Caption = "Chuyển Bàn";
            this.barButtonChuyenBan.Id = 2;
            this.barButtonChuyenBan.ImageUri.Uri = "Replace";
            this.barButtonChuyenBan.Name = "barButtonChuyenBan";
            this.barButtonChuyenBan.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonChuyenBan_ItemClick);
            // 
            // barButtonGopBan
            // 
            this.barButtonGopBan.Caption = "Gộp Bàn";
            this.barButtonGopBan.Id = 3;
            this.barButtonGopBan.ImageUri.Uri = "Refresh";
            this.barButtonGopBan.Name = "barButtonGopBan";
            this.barButtonGopBan.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonGopBan_ItemClick);
            // 
            // barButtonItem5
            // 
            this.barButtonItem5.Id = 4;
            this.barButtonItem5.Name = "barButtonItem5";
            // 
            // barButtonDatBan
            // 
            this.barButtonDatBan.Caption = "Đặt Bàn";
            this.barButtonDatBan.Id = 5;
            this.barButtonDatBan.ImageUri.Uri = "Apply";
            this.barButtonDatBan.Name = "barButtonDatBan";
            this.barButtonDatBan.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonDatBan_ItemClick);
            // 
            // barButtonTachBan
            // 
            this.barButtonTachBan.Caption = "Tách Bàn";
            this.barButtonTachBan.Id = 6;
            this.barButtonTachBan.ImageUri.Uri = "Cut";
            this.barButtonTachBan.Name = "barButtonTachBan";
            this.barButtonTachBan.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonTachBan_ItemClick);
            // 
            // barButtonChonMon
            // 
            this.barButtonChonMon.Caption = "Gọi Món";
            this.barButtonChonMon.Id = 7;
            this.barButtonChonMon.ImageUri.Uri = "Edit";
            this.barButtonChonMon.Name = "barButtonChonMon";
            this.barButtonChonMon.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonChonMon_ItemClick);
            // 
            // groupControl1
            // 
            this.groupControl1.Controls.Add(this.tblTable1);
            this.groupControl1.Location = new System.Drawing.Point(5, 111);
            this.groupControl1.Name = "groupControl1";
            this.groupControl1.Size = new System.Drawing.Size(560, 556);
            this.groupControl1.TabIndex = 2;
            this.groupControl1.Text = "Danh Sách Bàn";
            // 
            // tblTable1
            // 
            this.tblTable1.AutoScroll = true;
            this.tblTable1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblTable1.Location = new System.Drawing.Point(2, 23);
            this.tblTable1.Name = "tblTable1";
            this.tblTable1.Size = new System.Drawing.Size(556, 531);
            this.tblTable1.TabIndex = 0;
            // 
            // menuBan
            // 
            this.menuBan.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonChonMon),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonDatBan),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonXoaBan),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonChuyenBan),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonTachBan),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonGopBan)});
            this.menuBan.Manager = this.barManager1;
            this.menuBan.Name = "menuBan";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 37.57396F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 62.42604F));
            this.tableLayoutPanel1.Controls.Add(this.labelControl3, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.labelControl1, 0, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(376, 5);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 37.64706F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 62.35294F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(339, 86);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // labelControl1
            // 
            this.labelControl1.Appearance.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelControl1.Location = new System.Drawing.Point(4, 4);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.labelControl1.Size = new System.Drawing.Size(120, 25);
            this.labelControl1.TabIndex = 0;
            this.labelControl1.Text = "TỔNG TIỀN";
            // 
            // labelControl3
            // 
            this.labelControl3.Appearance.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelControl3.Location = new System.Drawing.Point(4, 36);
            this.labelControl3.Name = "labelControl3";
            this.labelControl3.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.labelControl3.Size = new System.Drawing.Size(120, 46);
            this.labelControl3.TabIndex = 2;
            this.labelControl3.Text = "TỔNG TIỀN";
            // 
            // frmBanHang
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1307, 679);
            this.Controls.Add(this.panelControl1);
            this.Controls.Add(this.barDockControlLeft);
            this.Controls.Add(this.barDockControlRight);
            this.Controls.Add(this.barDockControlBottom);
            this.Controls.Add(this.barDockControlTop);
            this.FormBorderEffect = DevExpress.XtraEditors.FormBorderEffect.Shadow;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.MaximizeBox = false;
            this.Name = "frmBanHang";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "HỆ THỐNG QUẢN LÝ NHÀ HÀNG - CAFE";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmBanHang_FormClosing);
            this.Load += new System.EventHandler(this.frmBanHang_Load);
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).EndInit();
            this.panelControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.groupControl4)).EndInit();
            this.groupControl4.ResumeLayout(false);
            this.groupControl4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl4)).EndInit();
            this.panelControl4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.panelControl3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl2)).EndInit();
            this.panelControl2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridControlCTHD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.barManager1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).EndInit();
            this.groupControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.menuBan)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraEditors.PanelControl panelControl1;
        private DevExpress.XtraEditors.GroupControl groupControl1;
        private DevExpress.XtraEditors.PanelControl panelControl2;
        private DevExpress.XtraEditors.PanelControl panelControl4;
        private DevExpress.XtraEditors.PanelControl panelControl3;
        private DevExpress.XtraEditors.GroupControl groupControl4;
        private DevExpress.XtraEditors.SimpleButton btnTrong;
        private DevExpress.XtraEditors.SimpleButton btnCoNguoi;
        private DevExpress.XtraEditors.SimpleButton btnDatTruoc;
        private DevExpress.XtraEditors.LabelControl txtTyLyPhucVu;
        private System.Windows.Forms.FlowLayoutPanel tblTable1;
        private DevExpress.XtraBars.PopupMenu menuBan;
        private DevExpress.XtraBars.BarButtonItem barButtonItem1;
        private DevExpress.XtraBars.BarButtonItem barButtonXoaBan;
        private DevExpress.XtraBars.BarButtonItem barButtonChuyenBan;
        private DevExpress.XtraBars.BarButtonItem barButtonGopBan;
        private DevExpress.XtraBars.BarManager barManager1;
        private DevExpress.XtraBars.BarDockControl barDockControlTop;
        private DevExpress.XtraBars.BarDockControl barDockControlBottom;
        private DevExpress.XtraBars.BarDockControl barDockControlLeft;
        private DevExpress.XtraBars.BarDockControl barDockControlRight;
        private DevExpress.XtraBars.BarButtonItem barButtonItem5;
        private DevExpress.XtraBars.BarButtonItem barButtonDatBan;
        private DevExpress.XtraBars.BarButtonItem barButtonChonMon;
        private DevExpress.XtraBars.BarButtonItem barButtonTachBan;
        private DevExpress.XtraGrid.GridControl gridControlCTHD;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn2;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn3;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn4;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn5;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn6;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn7;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn8;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn9;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private DevExpress.XtraEditors.LabelControl labelControl3;
        private DevExpress.XtraEditors.LabelControl labelControl1;

    }
}